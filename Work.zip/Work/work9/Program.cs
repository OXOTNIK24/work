﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace work9
{
    class Program
    {
        static void Main(string[] args)
        {
            //Ներմուծեք ուղանկյան կողմերը, հաշվեք դրա պարագիծն ու մակերեսը
            Console.Write("a=");
            string a = Console.ReadLine();
            double a1 = double.Parse(a);
            Console.Write("b=");
            string b = Console.ReadLine();
            double b1 = double.Parse(b);
            var paragice = a1 + b1 + a1 + b1;
            var makeres = a1 * b1;
            Console.WriteLine("Paragice=" +paragice );
            Console.WriteLine("Makeres=" + makeres);
            Console.ReadKey();

        }
    }
}
