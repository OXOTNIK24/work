﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace work2
{
    class Program
    {
        static void Main(string[] args)
        {
            //Հաշվել, թե a թիվը b թվի ո՞ր տոկոսն է կազմում օգտագործելով p = 100 * a / b բանաձևը։
            Console.Write("a=");
            string a = Console.ReadLine();
            int a1 = int.Parse(a);
            Console.Write("b=");
            string b = Console.ReadLine();
            int b1 = int.Parse(b);
            var p = 100 * a1 / b1;
            Console.WriteLine("p="+p +"%");
            Console.ReadKey();
        }
    }
}
