﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace work3
{
    class Program
    {
        static void Main(string[] args)
        {
            //Հաշվել r շառավղով շրջանի մակերեսը օգտագործելով a = pi * r * r բանաձևը։
            const double pi = 3.14;
            Console.Write("r=");
            string r = Console.ReadLine();
            double r1 = double.Parse(r);
            var a = pi * r1 * r1;
            Console.WriteLine("a=" +a + "m^2");
            Console.ReadKey();


        }
    }
}
