﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Work4
{
    class Program
    {
        static void Main(string[] args)
        {
            //Հաշվել r շառավղով շրջանագծի երկարությունը օգտագործելով c = 2 * pi * r բանաձևը։
            const double pi = 3.14;
            Console.Write("r=");
            string r = Console.ReadLine();
            double r1 = double.Parse(r);
            var c = 2 * pi * r1 ;
            Console.WriteLine("c=" + c + "m");
            Console.ReadKey();
        }
    }
}
