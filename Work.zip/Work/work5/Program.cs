﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace work5
{
    class Program
    {
        static void Main(string[] args)
        {
            //Հաշվել, թե քանի վայրկյան կա n քանակությամբ օրերում։
            Console.Write("n=");
            string a = Console.ReadLine();
            int a1 = int.Parse(a);
            var n = a1 * 24 * 60 * 60;
            Console.WriteLine("n=" + n + "sec");
            Console.ReadKey();
        }
    }
}
