﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Work
{
    class Program
    {
        static void Main(string[] args)
        {
            //Արտածեք Ձեր անունը, ազգանունը և տարիքը։
            string name = "Albert";
            string surname = "Hakobyan";
            int age = 24;
            Console.WriteLine("Name-" +name + "\nSurname-" + surname + "\nAge-" + age);
            Console.ReadKey();

        }
    }
}
