﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace work7
{
    class Program
    {
        static void Main(string[] args)
        {
            //Ներմուծեք ցանկացած երկու string, ստուգեք՝ արդյոք դրանք հավասար են միմյանց, տպեք արդյունքը 
            Console.Write("a=");
            string a = Console.ReadLine();
            int a1 = int.Parse(a);
            Console.Write("b=");
            string b = Console.ReadLine();
            int b1 = int.Parse(b);
            if (a1 == b1)
                Console.WriteLine("a=b");
            else
                Console.WriteLine("Error");
            Console.ReadKey();
        }
    }
}
