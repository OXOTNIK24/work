﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace work8
{
    class Program
    {
        static void Main(string[] args)
        {
            //Ներմուծեք երկու կոտորակային թիվ, տպեք դրանց գումարը՝ 1.որպես ամբողջ թիվ, 2.որպես կոտորակային թիվ,
            Console.Write("a=");
            string a = Console.ReadLine();
            double a1 = double.Parse(a);
            Console.Write("b=");
            string b = Console.ReadLine();
            double b1 = double.Parse(b);
            var c = a1 + b1;
            var n = a1 + b1;
            Console.WriteLine("a+b=" + n);
            Console.WriteLine("a+b=" +(int) + c);
            Console.ReadKey();
        }
    }
}
