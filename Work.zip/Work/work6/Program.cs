﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace work6
{
    class Program
    {
        static void Main(string[] args)
        {
            //Ներմուծեք երկու թիվ, տպեք դրանցից մեծը/փոքրը
            Console.Write("a=");
            string a = Console.ReadLine();
            double a1 = double.Parse(a);
            Console.Write("b=");
            string b = Console.ReadLine();
            double b1 = double.Parse(b);
            if ( a1 > b1 ) 
            {
                Console.WriteLine("big/small=" + a1 / b1);
            }
            if (b1 > a1)
            {
                Console.WriteLine("big/small=" + b1 / a1);
            } 
            Console.ReadKey();

        }
    }
}
